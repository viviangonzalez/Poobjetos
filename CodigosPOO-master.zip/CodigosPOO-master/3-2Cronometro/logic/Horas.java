/*
 * Hora.java
 * 
 * Created on 6/09/2007, 10:47:07 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author alejo
 */
class Horas extends UnidadTiempo{

    public Horas() {
        this.valor=0;
        this.tope=23;
    }

}
