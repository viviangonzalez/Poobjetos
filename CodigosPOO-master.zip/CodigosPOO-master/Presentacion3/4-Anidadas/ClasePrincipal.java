
public class ClasePrincipal {
	
	public class Anidada{
		private int numero =9;
		
		public int getNumero(){
			return numero;
		}
	}
	
	public Anidada getAnidada (){return new Anidada();}
}
