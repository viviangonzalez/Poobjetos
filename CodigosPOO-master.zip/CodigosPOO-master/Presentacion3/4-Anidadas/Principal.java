
public class Principal {

	/**
	 * este es el metodo principal
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClasePrincipal objClasePrincipal = new ClasePrincipal();
		System.out.println(objClasePrincipal.getAnidada().getNumero());

	}

}
