
public class Chef {
	protected int edad = 50;

	public void metodo() {
		// TODO Auto-generated method stub
		
	}

	public void metodo2() {
		// TODO Auto-generated method stub
		
	}

}
