
package herencia;

public abstract class Barco extends Vehiculo {
    public abstract void metodo1();

    public void metodo2()
    {
        System.out.println("soy el metodo 2");
    }

}
