/*
 * Hexadecimal.java
 * 
 * Created on 4/04/2008, 01:40:22 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package logic;

/**
 *
 * @author alejo
 */
public class Hexadecimal extends Sistema{

    public Hexadecimal() {
        this.base = 16;
    }

}
