/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package test;
import logica.Cuadrito;

/**
 *
 * @author chamo
 */
public class TestCuadrito {
    public static void main(String[] args){
        /*Cuadrito c = new Cuadrito();
        c.iniciarCuadrito();
        int m[][] = c.getCuadrito();
        for(int f=0;f<3;f++){
            for(int s=0;s<3;s++){
                System.out.print(m[f][s]+"\t");
            }
            System.out.println();
        }*/
        Double d = 2.95;
	int i = (int)Math.round(d);	
	System.out.println(i);
    }

}
